<?php
header('Location: Interfaces/Interfazlogin.php');
exit;
